Print 

JointPlate5 should be printed with supports, with the counterbore side on the base plate.

(2) JointPlate3.stl
(2) JointPlate5.stl
(1) rearLeg_bot.stl
(1) TopRearLeg3.stl